/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gofish;

import java.util.ArrayList;
import java.util.Scanner;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author shrut
 */
public class GofishTest {
    
    public GofishTest() {
    }
    
    @Before
    public void setUp() {
    }

    /**
     * Test of main method, of class Gofish.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Gofish.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of playGame method, of class Gofish.
     */
    @Test
    public void testPlayGame() {
        System.out.println("playGame");
        ArrayList<Integer> pool = null;
        Scanner input = null;
        Gofish.playGame(pool, input);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showGameState method, of class Gofish.
     */
    @Test
    public void testShowGameState() {
        System.out.println("showGameState");
        ArrayList<Integer> player2 = null;
        ArrayList<Integer> player1Pile = null;
        ArrayList<Integer> player2Pile = null;
        Gofish.showGameState(player2, player1Pile, player2Pile);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of playOneTurn method, of class Gofish.
     */
    @Test
    public void testPlayOneTurn() {
        System.out.println("playOneTurn");
        int card = 0;
        ArrayList<Integer> chooser = null;
        ArrayList<Integer> cardChosen = null;
        ArrayList<Integer> chooserPile = null;
        ArrayList<Integer> chosenPile = null;
        ArrayList<Integer> pool = null;
        Gofish.playOneTurn(card, chooser, cardChosen, chooserPile, chosenPile, pool);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of distributedDeck method, of class Gofish.
     */
    @Test
    public void testDistributedDeck() {
        System.out.println("distributedDeck");
        ArrayList<Integer> deck = null;
        ArrayList<Integer> play1 = null;
        ArrayList<Integer> play2 = null;
        Gofish.distributedDeck(deck, play1, play2);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of createDeck method, of class Gofish.
     */
    @Test
    public void testCreateDeck() {
        System.out.println("createDeck");
        ArrayList<Integer> expResult = null;
        ArrayList<Integer> result = Gofish.createDeck();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showCards method, of class Gofish.
     */
    @Test
    public void testShowCards() {
        System.out.println("showCards");
        ArrayList<Integer> cards = null;
        Gofish.showCards(cards);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
