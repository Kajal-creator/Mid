package gofish;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.Random;
/** Go Fish!
 * 
 * @author shruti kajal
 *
 */
public class Gofish {

	private static final int HAND_SIZE = 7;
	
	public static void main(String[] args) 
	{
	        ArrayList<Integer> pool = createDeck();
		Scanner input = new Scanner(System.in);
		
		Collections.shuffle(pool);
		playGame(pool, input);
	}
	
	public static void playGame(ArrayList<Integer> pool, Scanner input)
	{
		ArrayList<Integer> player1 = new ArrayList<Integer>();
		ArrayList<Integer> player2 = new ArrayList<Integer>();
		ArrayList<Integer> player1Pile = new ArrayList<Integer> ();
		ArrayList<Integer> player2Pile = new ArrayList<Integer>();

		
		showGameState(player2, player1Pile, player2Pile);
		Random random = new Random();
		// Play the game
		while (player1Pile.size() + player2Pile.size() < 52 || !pool.isEmpty())
		{
			if (!player2.isEmpty())
			{
				System.out.println("What card do you want?");
				int card = input.nextInt();
				
				// Play turn with the player2
				
				playOneTurn(card, player2, player1, player2Pile, player1Pile, pool);
			}
			else
			{
				int cardFromPile = random.nextInt(pool.size());
				player2.add(pool.get(cardFromPile));
				pool.remove(cardFromPile);
			}
			
			
			// Now it is the player1's turn
			if (!player1.isEmpty())
			{
				int card = player1.get((int)(Math.random()*player1.size()));	
				System.out.println("Do you have any "  + card + "'s ?");
				
				playOneTurn(card, player1, player2, player1Pile, player2Pile, pool);
			}
			else if (!pool.isEmpty())
			{
				int cardFromPile = random.nextInt(pool.size());
				player2.add(pool.get(cardFromPile));
				pool.remove(cardFromPile);
			}
			
			showGameState(player2, player1Pile, player2Pile);
		}
		
		if ( player2Pile.size() > player1Pile.size())
		{
			System.out.println("You are the winner with " + player2Pile.size() + " books");
		}
		if ( player2Pile.size() < player1Pile.size())
		{
			System.out.println("You lost with the computer have " + player1Pile.size() + " books.");
		}
		if ( player2Pile.size() == player1Pile.size())
		{
			System.out.println("The game is a tie with " + player1Pile.size() + " books.");
		}			
	}
	
	
	public static void showGameState(ArrayList<Integer> player2, ArrayList<Integer> player1Pile,
			ArrayList<Integer> player2Pile)
	{
		System.out.println("Here are your cards");
		showCards(player2);
		System.out.println("Here is your pile");
		showCards(player2Pile);
		
	}
       
	/** @param card The card that has been selected.
	 * @param chooser The hand for the player who is currently choosing.
	 * @param cardChosen The hand for the player who is being asked for cards.
	 * @param chooserPile The pile for the player who is currently choosing.
	 * @param chosenPile The pile for the player who is being asked for cards.
	 * @param pool The deck of cards that have not yet been distributed, already sorted.
	 */
	public static void playOneTurn(int card, ArrayList<Integer> chooser, ArrayList<Integer> cardChosen,
			ArrayList<Integer> chooserPile, ArrayList<Integer> chosenPile, ArrayList<Integer> pool)
	{
		if (cardChosen.contains(card))
		{
			
			for ( int x = 0; x < chooser.size(); x++)
			{
				int smallDeck = 0;
					if (card == chooser.get(x))
					{
						smallDeck = smallDeck + 1;
					}
				if(smallDeck == 4)
				{
					chooserPile.add(card);
					for(int r = 0; r < chooser.size()+1; r++)
					{
						if (chooser.get(r) == card)
						{
							chooser.remove(r);
						}
					}
				}
				smallDeck = 0;	
			}
			
			
		}
		else
		{
			System.out.println("Go fish!");
			
			Random random = new Random();
			int cardFromPile = random.nextInt(pool.size());
			chooser.add(pool.get(cardFromPile));
			pool.remove(cardFromPile);
			int smallDeck = 0;
			for ( int x = 0; x < chooser.size(); x++)
			{
					if (card == chooser.get(x))
					{
						smallDeck++;
					}
			}
			if(smallDeck == 4)
			{
				chooserPile.add(card);
				for(int r = 0; r < chooser.size(); r++)
				{
					if (chooser.get(r) == card)
					{
						chooser.remove(r);
					}
				}
			}
			smallDeck = 0;
                }
        }
	public static void distributedDeck(ArrayList<Integer> deck, ArrayList<Integer> play1, ArrayList<Integer> play2)
	{
		Random rNum = new Random();
		int i = 0;
		while ( i <= HAND_SIZE )
		{
			int rIndex = rNum.nextInt(deck.size());
			play1.add(deck.get(rIndex));
			deck.remove(deck.get(rIndex));
			i++;
		}
		
		i = 0;
		while ( i <= HAND_SIZE )
		{
			int rIndex = rNum.nextInt(deck.size());
			play2.add(deck.get(rIndex));
			deck.remove(deck.get(rIndex));
			i++;
		}
		
	}
	
	/** Build a deck of 52 cards, 4 of each rank from 1 to 13
	 
	 */
	public static ArrayList<Integer> createDeck()
	{
		// Create a deck of cards
		ArrayList<Integer> finalDeck = new ArrayList<Integer>();
		int i = 0;
		while (i < 52)
		{
			int addDeck = i%13 + 1;
			finalDeck.add(addDeck);
			i++;
		}
		
		return finalDeck;
	}
	

	/** 
	 * @param cards The cards to be displayed
	 */
	public static void showCards(ArrayList<Integer> cards)
	{
		Collections.sort(cards);
	
		for (Integer i: cards)
		{
			System.out.print(i + " ");
		}
		System.out.println();
	}

}


